package com.ejercicios.ejerciciosjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
